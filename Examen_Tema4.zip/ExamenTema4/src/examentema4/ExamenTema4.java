package examentema4;

public class ExamenTema4 {

    public static int longitud(int numNarcisista) {

        int longitud = 0;

        while (numNarcisista > 0) {
            numNarcisista = numNarcisista / 10;
            longitud++;
        }
        return longitud;
    }

    public static int potencia(int numNarcisista) {

        int potencia = 0;

        for (int contador = longitud(numNarcisista); contador > 1; contador--) {
            potencia = potencia + digito(numNarcisista);
        }
        return potencia;
    }
    
    public static int digito(int numNarcisista) {

        int digito = 0;
        
        while (numNarcisista > 0) {
            digito = numNarcisista % 10;
            numNarcisista = numNarcisista / 10;
        }
        return digito;
    }

    public static void main(String[] args) {

        int contador = 20;

        System.out.println("Los 20 primeros números narcisistas son: ");     
        
        for (int numNarcisista = 1; contador > 0; numNarcisista++){
            if (numNarcisista == potencia(numNarcisista)){
               System.out.println(numNarcisista);
               contador--; 
            }
        }    

    }
}
