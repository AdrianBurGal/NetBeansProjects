
package Actividad_Aplicacion_7_14;

public class Main {

    public static void main(String[] args) {

        Cambio calculadora = new Cambio();
        calculadora.calcularCambio(21, 505.50);

    }

}
