package Tema_1;

import java.util.Scanner;

public class Examen_Tema_1 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int numero1, numero2, resto, numeroMayor, numeroMenor;
        boolean respuesta;
       
        System.out.print("Introduzca el primer número: ");
        numero1 = teclado.nextInt();

        System.out.print("Introduzca el segundo número: ");
        numero2 = teclado.nextInt();

        // Miramos cual es el numero mayor y el menor.
        numeroMayor = numero1 >= numero2 ? numero1 : numero2;
        numeroMenor = numero1 < numero2 ? numero1 : numero2;
        
        /* Calculamos el resto diviendo siempre el numero mayor por el menor.
          Para ello creamos la siguiene condición y se realiza el calculo.
         */
        resto = numeroMayor % numeroMenor;

        // Si el resto es 0 nos dirá que es verdadero, sino nos dirá que es falso.
        respuesta = resto == 0;
        
        System.out.println("Es el número " + numeroMayor + " divisible por " + numeroMenor + "? " + respuesta);

    }

}
