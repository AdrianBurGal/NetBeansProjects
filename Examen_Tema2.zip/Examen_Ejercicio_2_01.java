package tema2;

import java.util.Scanner;

public class Examen_Ejercicio_1 {

    public static void main(String[] args) {

        double valor1, valor2;
        char operador;

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca el primer valor: ");
        valor1 = teclado.nextDouble();

        System.out.print("Introduzca el segundo valor: ");
        valor2 = teclado.nextDouble();

        System.out.print("Introduzca el operador (+,-,*,/): ");
        operador = teclado.next().charAt(0);

        switch (operador) {
            case '+' -> {
                System.out.print("El resultado de la operación es: " + (valor1 + valor2));
            }
            case '-' -> {
                System.out.print("El resultado de la operación es: " + (valor1 - valor2));
            }
            case '*' -> {
                System.out.print("El resultado de la operación es: " + (valor1 * valor2));
            }
            case '/' -> {
                System.out.print("El resultado de la operación es: " + (valor1 / valor2));
            }
            default -> {
                System.out.print("Introduzca otro operador.");

            }
        }
    }
}
