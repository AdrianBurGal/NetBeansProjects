package tema2;

import java.util.Scanner;

public class Examen_Ejercicio_2 {

    public static void main(String[] args) {

        int numero, unidad, decena, centena, cociente;

        Scanner teclado = new Scanner(System.in);

        System.out.println("Introduzca un número de 3 cifras: ");
        numero = teclado.nextInt();

        numero = Math.abs(numero);
        
        if (numero <= 999) {
                    
            unidad = numero % 10;
            cociente = numero / 10;
            decena = cociente % 10;
            centena = cociente / 10;
            
            System.out.println("El número dado la vuelta sería: " + unidad + decena + centena);
            
        } else {
            System.out.println("El número introducido no no cumple el formato requerido.");
        }
    }
}
