package examen_tema3;

import java.util.Scanner;

public class Ejercicio_Examen_3_01 {

    public static void main(String[] args) {

        long numero, digito, crapulo = 0, reservado = 0;

        Scanner teclado = new Scanner(System.in);

        do { // bucle para controlar si el número es positivo.
            System.out.print("Introduzca un número positivo: ");
            numero = teclado.nextLong();
        } while (numero < 0);

        while (numero > 0) { // calcula el crápulo.
            digito = numero % 10;
            numero = numero / 10;
            crapulo = crapulo + digito;
        }

        if (crapulo >= 10) { // si el crápulo es mayor de 10 seguirá sumando sus dígitos.
            while (crapulo > 0) {
                digito = crapulo % 10;
                crapulo = crapulo / 10;
                reservado = reservado + digito;
            }
            System.out.printf("El crápulo del número es %d.\n",reservado);
        } else {
            System.out.printf("El crápulo del número es %d.\n",crapulo);

        }
    }
}
