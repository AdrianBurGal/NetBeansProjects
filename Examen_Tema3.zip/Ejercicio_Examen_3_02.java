package examen_tema3;

import java.util.Scanner;

public class Ejercicio_Examen_3_02 {

    public static void main(String[] args) {

        long numero, digito, reverso = 0, resultado = 0, totalDigitos = 0;
        char respuesta;

        Scanner teclado = new Scanner(System.in);

        do { // bucle para seguir con el programa o no.
            do { // bucle para controlar si el número es positivo.
                System.out.print("Introduzca un número positivo: ");
                numero = teclado.nextLong();
            } while (numero < 0);

            while (numero > 0) { // bucle para hacer el reverso.
                digito = numero % 10;
                numero = numero / 10;
                reverso = (reverso * 10) + digito;
                totalDigitos++; // suma el total de dígitos que lo usaremos para el próximo for.
            }

            resultado = 0; // reiniciamos el resultado por si se repite el bucle y no se sume con el anterior.
            for (; reverso > 0; totalDigitos--) {

                digito = reverso % 10;
                reverso = reverso / 10;
                resultado = resultado + digito;

                if (totalDigitos > 1) { // if para pintar la suma correctamente.
                    System.out.print(digito + " + ");
                } else {
                    System.out.println(digito + " = " + resultado);
                }
            }

            System.out.println("¿Quiere seguir con el programa?");
            System.out.println("Sí[cualquier letra] / No[s] ");
            respuesta = teclado.next().charAt(0);

        } while (respuesta != 's');
    }
}
